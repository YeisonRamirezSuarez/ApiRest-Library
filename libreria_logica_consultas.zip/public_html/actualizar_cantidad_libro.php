<?php
include("conexion.php");

if(isset($_GET['id']) && isset($_GET['Cantidad_libro'])){
    $id = $_GET["id"];
    $Cantidad_libro=$_GET["Cantidad_libro"];
    $q=mysqli_query($conexion,"UPDATE libros SET Cantidad_libro = '$Cantidad_libro' WHERE _id = '$id'");

    if($q){
        echo "correcto";
    }
    else{
        echo "Fallo";
    }
}else{
    echo "No hay nada dentro de los parametros";
}

