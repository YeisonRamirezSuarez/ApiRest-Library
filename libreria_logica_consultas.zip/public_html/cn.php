<?php
$hostname='localhost';
$database='id19666383_prueba';
$username='id19666383_prueba_user';
$password='k[fdO9zy*rv3s@B\\';

$conexion=new mysql_connect($hostname,$username,$password,$database);
if($c->connect_errno){
    echo "El sitio web está experimentado problemas 1";
}
?>