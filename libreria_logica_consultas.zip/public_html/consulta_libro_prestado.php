<?php
include 'conexion.php';
if(isset($_GET['correo'])){

//$libro_id=$_GET['id'];
$correo=$_GET['correo'];
//$sentencia=$conexion->prepare("SELECT * FROM libros_prestados WHERE _id_Libro='$libro_id' AND Correo_Prestamo_libro='$correo'");
$sentencia=$conexion->prepare("SELECT * FROM libros_prestados WHERE Correo_Prestamo_libro='$correo'");

$sentencia->execute();
$resultado = $sentencia->get_result();

    $fila = array(
        "libros_prestados" => [
        ] 
    );

    $cont = 0;
    
    for($i=0; $i< $resultado->num_rows; $i++){
        $fila["libros_prestados"][$cont] = $resultado -> fetch_assoc();
        $cont++;
    }

    
    echo json_encode($fila); 
    //echo $fila["Rol_Usuario"];
    $sentencia->close();
    $conexion->close();   
    


}else{

echo "No hay nada dentro de los parametros";
}

?>