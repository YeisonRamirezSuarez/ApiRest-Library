<?php
include 'conexion.php';
if(isset($_GET['id'])){

$libro_id=$_GET['id'];
$sentencia=$conexion->prepare("SELECT * FROM libros WHERE _id='$libro_id'");

$sentencia->execute();
$resultado = $sentencia->get_result();




    
    $fila = array(

        "libros" => [
        ] 
    );


    $fila["libros"][0] = $resultado -> fetch_assoc();
      
    
    echo json_encode($fila,JSON_UNESCAPED_UNICODE); 
    //echo $fila["Rol_Usuario"];
    $sentencia->close();
    $conexion->close();   
    


}else{

echo "No hay nada dentro de los parametros";
}

?>