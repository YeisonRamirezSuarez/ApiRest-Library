<?php
include 'conexion.php';
if(isset($_GET['correo'])){

$usu_usuario=$_GET['correo'];
$sentencia=$conexion->prepare("SELECT * FROM usuario WHERE Correo_Electronico='$usu_usuario'");

$sentencia->execute();
$resultado = $sentencia->get_result();




    
    $fila = array(

        "usuarios" => [
        ] 
    );


    $fila["usuarios"][0] = $resultado -> fetch_assoc();
      
    
    echo json_encode($fila,JSON_UNESCAPED_UNICODE); 
    //echo $fila["Rol_Usuario"];
    $sentencia->close();
    $conexion->close();   
    


}else{

echo "No hay nada dentro de los parametros";
}

?>