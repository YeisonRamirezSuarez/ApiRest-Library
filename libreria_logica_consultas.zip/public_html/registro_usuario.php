<?php
$nombre=$_GET["Nombre_Usuario"];
$correo=$_GET["CorreoElectronico_Usuario"];
$telefono=$_GET["Telefono_Usuario"];
$direccion=$_GET["Direccion_Usuario"];
$contrasena=$_GET["Contrasena_Usuario"];


$cont=0;
include("conexion.php");
$q=mysqli_query($conexion,"INSERT INTO usuario( Nombre_Usuario, Correo_Electronico, Telefono_Usuario, Direccion_Usuario, Contrasena_Usuario, Rol_Usuario) VALUES ('$nombre',
 '$correo', '$telefono', '$direccion', '$contrasena', 'usuario')");

if($q){
    echo "Registro insertado exitoso";
}
else{
    echo "Fallo en el registro";
}
